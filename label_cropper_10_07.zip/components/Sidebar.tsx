"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

export default function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="w-64 bg-white border-r border-cyan-300 h-full flex flex-col p-4 space-y-4 fixed left-0 top-0">
      <Link
        href="/"
        className={`px-4 py-3 rounded-lg border-2 transition-all font-semibold ${
          pathname === "/"
            ? "border-cyan-300 text-cyan-500 bg-cyan-50 shadow-sm"
            : "border-transparent text-gray-600 hover:bg-gray-50"
        }`}
      >
        Label Cropper
      </Link>
      
      <Link
        href="/synthesizer"
        className={`px-4 py-3 rounded-lg border-2 transition-all font-semibold ${
          pathname === "/synthesizer"
            ? "border-cyan-300 text-cyan-500 bg-cyan-50 shadow-sm"
            : "border-transparent text-gray-600 hover:bg-gray-50"
        }`}
      >
        Generate Image
      </Link>
    </aside>
  );
}
